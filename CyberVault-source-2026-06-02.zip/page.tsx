"use client";
import ChangePassword from "@/src/app/_components/ChangePassword/ChangePassword";
import PersonalData from "@/src/app/_components/PersonalData/PersonalData";
import { profileDataType } from "@/src/types/types";
import { useEffect, useState } from "react";

export default function Profile() {
  const [profileData, setProfileData] = useState<profileDataType | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<"profile" | "password">("profile");

  useEffect(() => {
    async function fetchProfileData() {
      try {
        const res = await fetch("/api/profileAPI", {
          headers: {
            "Content-Type": "application/json",
          },
          method: "GET",
        });
        const result = await res.json();
        setProfileData(result.data);
      } finally {
        setIsLoading(false);
      }
    }

    fetchProfileData();
  }, []);

  return (
    <>
      {isLoading ? (
        <div className="container min-h-screen flex items-center justify-center">
          <div className="grid min-h-35 w-full place-items-center overflow-x-hidden rounded-lg p-6 lg:overflow-visible">
            <svg
              className="w-16 h-16 animate-spin text-gray-900/50"
              viewBox="0 0 64 64"
              fill="none"
              xmlns="http://www.w3.org/2000/svg"
              width="24"
              height="24"
            >
              <path
                d="M32 3C35.8083 3 39.5794 3.75011 43.0978 5.20749C46.6163 6.66488 49.8132 8.80101 52.5061 11.4939C55.199 14.1868 57.3351 17.3837 58.7925 20.9022C60.2499 24.4206 61 28.1917 61 32C61 35.8083 60.2499 39.5794 58.7925 43.0978C57.3351 46.6163 55.199 49.8132 52.5061 52.5061C49.8132 55.199 46.6163 57.3351 43.0978 58.7925C39.5794 60.2499 35.8083 61 32 61C28.1917 61 24.4206 60.2499 20.9022 58.7925C17.3837 57.3351 14.1868 55.199 11.4939 52.5061C8.801 49.8132 6.66487 46.6163 5.20749 43.0978C3.7501 39.5794 3 35.8083 3 32C3 28.1917 3.75011 24.4206 5.2075 20.9022C6.66489 17.3837 8.80101 14.1868 11.4939 11.4939C14.1868 8.80099 17.3838 6.66487 20.9022 5.20749C24.4206 3.7501 28.1917 3 32 3L32 3Z"
                stroke="currentColor"
                strokeWidth="5"
                strokeLinecap="round"
                strokeLinejoin="round"
              ></path>
              <path
                d="M32 3C36.5778 3 41.0906 4.08374 45.1692 6.16256C49.2477 8.24138 52.7762 11.2562 55.466 14.9605C58.1558 18.6647 59.9304 22.9531 60.6448 27.4748C61.3591 31.9965 60.9928 36.6232 59.5759 40.9762"
                stroke="currentColor"
                strokeWidth="5"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="text-gray-900"
              ></path>
            </svg>
          </div>
        </div>
      ) : (
        <div className="container mx-auto px-4 py-8 min-h-screen flex justify-center items-center">
          <div className="w-11/12 md:w-10/12 space-y-5">
            <div className="flex flex-wrap gap-3">
              <button
                type="button"
                onClick={() => setActiveTab("profile")}
                className={`rounded-lg px-4 py-2.5 text-sm font-semibold transition-colors duration-200 ${
                  activeTab === "profile"
                    ? "bg-blue-700 text-white"
                    : "bg-white text-gray-700 border border-gray-300 hover:bg-gray-100"
                }`}
              >
                My Profile
              </button>
              <button
                type="button"
                onClick={() => setActiveTab("password")}
                className={`rounded-lg px-4 py-2.5 text-sm font-semibold transition-colors duration-200 ${
                  activeTab === "password"
                    ? "bg-blue-700 text-white"
                    : "bg-white text-gray-700 border border-gray-300 hover:bg-gray-100"
                }`}
              >
                Change Password
              </button>
            </div>

            {activeTab === "profile" ? (
              profileData ? (
                <PersonalData profileData={profileData} />
              ) : (
                <div className="rounded-lg border border-red-300 bg-red-50 p-4 text-red-700">
                  Unable to load profile data.
                </div>
              )
            ) : (
              <ChangePassword />
            )}
          </div>
        </div>
      )}
    </>
  );
}
