# CyberVault Frontend — Backend Integration Fixes

> Generated: 2026-06-02
> Spec version: 2.0.0

---

## Overview

This document details every mismatch found between the existing frontend and the backend API, and documents exactly what was changed and why. All fixes reference the backend spec §§7–13.

---

## Files Modified / Created

### 1. `.env.local` — No change needed
The `BACKEND_URL=https://api.cybervault.systems/api/v1` is already correct and already includes `/api/v1`. All `backendFetch()` paths are relative and do **not** re-include `/api/v1`.

---

### 2. `auth.ts` — FIXED

**Problems found:**
- The fallback `BACKEND_URL` in `auth.ts` was `http://localhost:5000/api/v1` (hardcoded) instead of using `process.env.BACKEND_URL`.
- `expiresAt` was being set inside the JWT callback but NOT passed from `authorize()`, causing the token to always use the fallback `Date.now() + 10 * 60 * 1000` on first login — meaning the proactive refresh would fire 30s before the **fallback** expiry, not the actual JWT expiry.
- When a new access token was refreshed, `mustChangePassword` was never synced from the new token's payload into `token.user.mustChangePassword`, so the proxy middleware would not update the `mustChangePassword` guard after a password change.

**Fixes:**
- `BACKEND_URL` now reads from `process.env.BACKEND_URL` with the same fallback.
- `expiresAt` is now decoded from the JWT in `authorize()` and passed in the `User` object so the JWT callback stores the real expiry on first login.
- After a successful token refresh, the new token's `mustChangePassword` payload field is decoded and synced into `token.user`.

---

### 3. `backendClient.ts` — MINOR IMPROVEMENTS

No structural changes. Added inline comments mapping to the spec error code registry (§13.3) so consumers know which `ApiError.code` values to handle.

---

### 4. `LoginForm.tsx` — FIXED

**Problem found:**
- On login failure, the form only showed a generic "Invalid credentials" message regardless of the actual backend error code.
- Backend spec §7.2 & §13.3 define specific error codes with user-actionable info:
  - `ACCOUNT_LOCKED` includes `remainingSeconds` in `error.details` — user needs to know how long to wait.
  - `ACCOUNT_INACTIVE` — account has been deactivated by admin.
  - `INVALID_CREDENTIALS` — wrong bankUserId or password.

**Fix:**
- Added a pre-flight call to `/api/loginAPI` (new route, see below) to get the rich error response.
- Error messages are now tailored per code:
  - `ACCOUNT_LOCKED`: "Account locked. Try again in X minute(s)." (uses `remainingSeconds`)
  - `ACCOUNT_INACTIVE`: "Your account has been deactivated. Contact support."
  - `INVALID_CREDENTIALS`: "Invalid Bank ID or password. Please try again."

---

### 5. `DepartmentInformation.tsx` — FIXED (CRITICAL)

**Problem found:**
- The "Region" field was registered as `register("region")` but the backend spec §8.3 expects `department.departmentRegion`.
- The "Role" radio buttons were registered as `register("role")` / `Controller name="role"` but the backend spec §8.3 expects `department.departmentRole`.

These mismatches meant the employee creation form was sending `region` and `role` at the top level instead of inside the `department` object, causing `VALIDATION_ERROR` from the backend.

**Fix:**
- `register("region")` → `register("departmentRegion")`
- `Controller name="role"` → `Controller name="departmentRole"`
- The `registerAPI_route.ts` now reads `formData.departmentRegion` and `formData.departmentRole` correctly.

---

### 6. `Delete.tsx` — FIXED (CRITICAL BUG)

**Problem found:**
```ts
// BROKEN original code:
import { createContext } from "vm";        // ← Node.js 'vm' module, NOT React!
const {setSearchResult} = createContext(SearchResult);  // ← creates a new sandbox, crashes at runtime
```
This would throw a runtime error every time the Delete component was rendered because `createContext` from Node's `vm` module creates a V8 context sandbox, not a React context consumer.

**Fix:**
```ts
import { useContext, useState } from "react";
const { setSearchResult } = useContext(SearchResult);
```

Also added:
- `CANNOT_DELETE_ADMIN` error code handling with a specific toast message.
- "Deleting..." loading state text on the confirm button.

---

## New API Route Files Created

All new route files follow the Next.js App Router pattern (`route.ts`).
Place each file at the path shown.

---

### `src/app/api/loginAPI/route.ts` ← `loginAPI_route.ts`

**Purpose:** Pre-flight login call to get rich backend error codes before NextAuth session creation.

**Backend endpoint:** `POST /api/v1/auth/login`

**Key behavior:**
- Returns `{ ok: false, error: { code, message, details } }` with the backend's exact error object.
- `ACCOUNT_LOCKED` response includes `error.details.remainingSeconds` for countdown display.

---

### `src/app/api/changePasswordAPI/route.ts` ← `changePasswordAPI_route.ts`

**Purpose:** Change password via backend.

**Backend endpoint:** `PATCH /api/v1/profile/password`

**Request body:** `{ currentPassword, newPassword }`

**Key behavior:**
- On success, backend sets `mustChangePassword = false` in the DB (spec §8.2).
- Returns `{ ok: true, message: 'Password updated successfully' }`.
- On error returns `{ ok: false, message, error }` — `ChangePassword.tsx` checks `payload?.ok`.

---

### `src/app/api/transactionMethodsAPI/route.ts` ← `transactionMethodsAPI_route.ts`

**Purpose:** Credit, debit, and transfer transactions.

**Backend endpoints:**
- `POST /api/v1/transactions/credit`
- `POST /api/v1/transactions/debit`
- `POST /api/v1/transactions/transfer`

**Request from component:** `{ method: 'credit'|'debit'|'transfer', data: {...} }`

**Key behaviors:**
- Transfer body uses `sourceAccountNumber` / `destinationAccountNumber` (spec §8.4).
- Credit/debit body uses `accountNumber` (spec §8.4).
- Returns `{ ok: true, transaction: { id, type, amount, currency, balanceAfter, createdAt } }`.
- Maps backend error codes to user-friendly messages:
  - `INSUFFICIENT_FUNDS`, `ACCOUNT_FROZEN`, `CURRENCY_MISMATCH`, `SAME_ACCOUNT`, etc.

---

### `src/app/api/transactionsHistoryAPI/route.ts` ← `transactionsHistoryAPI_route.ts`

**Purpose:** Transaction history with pagination and type filtering.

**Backend endpoint:** `GET /api/v1/transactions/history`

**Key behaviors:**
- `filter: "All"` omits the `type` query param (backend default returns all).
- `filter: "credit"/"debit"/"transfer"` maps to the lowercase `type` param.
- Returns `HistoryRecord[]` items exactly matching the type in `types.ts`.
- `destinationAccount` is `null` for credit/debit; decrypted account number for transfers.
- `amount` and `balanceAfter` are JS `number` (from Sequelize `decimalNumbers: true`).

---

### `src/app/api/manageAPI/route.ts` ← `manageAPI_route.ts`

**Purpose:** Look up a user or employee by `bankUserId` and return their full profile.

**Backend endpoints used:**
1. `GET /api/v1/users?bankUserId=<searchParam>` — get DB integer `id`.
2. `GET /api/v1/users/:id` — get full profile with decrypted `phone` and `accountNumber`.

**Key behaviors:**
- Validates that the found user's `role` matches `whoWeSearch` ('user' vs 'employee'/'admin').
- Returns `{ profileData, secondaryData }`:
  - `secondaryData` is `accountDataType` for users, `departmentDataType` for employees.
- This replaces any old dummyjson/mock data calls.

---

### `src/app/api/deleteAPI/route.ts` ← `deleteAPI_route.ts`

**Purpose:** Delete a user by DB integer `id`.

**Backend endpoint:** `DELETE /api/v1/users/:id` (admin only, spec §8.3)

**Key behavior:**
- Returns `{ ok: true, message: 'User deleted successfully' }` on success.
- Handles `CANNOT_DELETE_ADMIN` (409) — cannot delete the last admin.
- The backend handles all FK cleanup internally in the correct order.

---

### `src/app/api/profileAPI/route.ts` ← `profileAPI_route.ts`

**Purpose:** Fetch the authenticated user's own profile.

**Backend endpoint:** `GET /api/v1/profile`

**Response shape** (spec §8.2):
```ts
{
  id, bankUserId, name, email, phone, dateOfBirth, gender, role,
  mustChangePassword,
  department: { departmentName, departmentRegion, departmentRole, departmentSince, departmentStatus } | null,
  account: { accountNumber, accountType, currency, balance, accountStatus },
  createdAt
}
```
`phone` and `accountNumber` are decrypted by the backend before returning.

---

### `src/app/api/registerAPI/route.ts` ← `registerAPI_route.ts`

**Purpose:** Create a new bank user or employee.

**Backend endpoints:**
- `POST /api/v1/users` — creates user + account
- `POST /api/v1/employees` — creates employee (no account)

**Key behaviors:**
- User creation returns `temporaryPassword = 'Bank@<bankUserId>'` — show this to the admin once.
- Employee creation returns department details and `temporaryPassword`.
- Handles `EMAIL_EXISTS` (409) and `NATIONAL_ID_EXISTS` (409).

---

### `src/app/api/accountLookupAPI/route.ts` ← `accountLookupAPI_route.ts`

**Purpose:** Look up an account by account number before transfers.

**Backend endpoint:** `GET /api/v1/accounts/lookup?accountNumber=...`

**Response:** `{ id, accountNumber, currency, accountStatus, owner: { name, bankUserId } }`

Useful for verifying the destination account currency matches before submitting a transfer.

---

### `src/app/api/usersListAPI/route.ts` ← `usersListAPI_route.ts`

**Purpose:** Paginated user list for admin/employee management tables.

**Backend endpoint:** `GET /api/v1/users?page=&limit=&name=&email=&bankUserId=&role=`

**Response:** `{ data: UserListItem[], pagination: { page, limit, total, pages } }`

---

### `src/app/api/unlockUserAPI/route.ts` ← `unlockUserAPI_route.ts`

**Purpose:** Unlock a locked user account (admin only).

**Backend endpoint:** `PATCH /api/v1/users/:id/unlock`

**Response:** `{ ok: true, message: 'User unlocked successfully' }`

---

### `next-auth.d.ts` — UPDATED

Extended `Session.user`, `User`, and `JWT` types to include all custom fields:
- `role: 'admin' | 'employee' | 'user'`
- `bankUserId: string`
- `mustChangePassword: boolean`
- `expiresAt: number` (in JWT)
- `error?: string` (in Session, for `RefreshAccessTokenError`)

---

## File Placement Guide

After extracting, place files at these paths in the Next.js project:

```
src/
├── app/
│   ├── api/
│   │   ├── loginAPI/route.ts              ← loginAPI_route.ts
│   │   ├── changePasswordAPI/route.ts     ← changePasswordAPI_route.ts
│   │   ├── transactionMethodsAPI/route.ts ← transactionMethodsAPI_route.ts
│   │   ├── transactionsHistoryAPI/route.ts← transactionsHistoryAPI_route.ts
│   │   ├── manageAPI/route.ts             ← manageAPI_route.ts
│   │   ├── deleteAPI/route.ts             ← deleteAPI_route.ts
│   │   ├── profileAPI/route.ts            ← profileAPI_route.ts
│   │   ├── registerAPI/route.ts           ← registerAPI_route.ts
│   │   ├── accountLookupAPI/route.ts      ← accountLookupAPI_route.ts
│   │   ├── usersListAPI/route.ts          ← usersListAPI_route.ts
│   │   └── unlockUserAPI/route.ts         ← unlockUserAPI_route.ts
│   └── ...
├── lib/
│   └── backendClient.ts                   ← backendClient.ts (replace existing)
├── components/
│   ├── DepartmentInformation/
│   │   └── DepartmentInformation.tsx      ← DepartmentInformation.tsx (replace)
│   ├── Delete/
│   │   └── Delete.tsx                     ← Delete.tsx (replace)
│   └── LoginForm/
│       └── LoginForm.tsx                  ← LoginForm.tsx (replace)
├── utilities/
│   ├── auth.ts                            ← auth.ts (replace)
│   └── ...
└── next-auth.d.ts                         ← next-auth.d.ts (replace)
```

`.env.local` is already correct — no change needed.

---

## Backend Error Code Reference (spec §13.3)

| Code | HTTP | Meaning | Where handled |
|---|---|---|---|
| `VALIDATION_ERROR` | 400 | Zod schema failure | All API routes |
| `INVALID_CREDENTIALS` | 401 | Wrong bankUserId or password | LoginForm |
| `ACCOUNT_LOCKED` | 401 | Too many failed attempts | LoginForm (shows remainingSeconds) |
| `ACCOUNT_INACTIVE` | 400 | User deactivated | LoginForm |
| `ACCOUNT_FROZEN` | 403 | Account not active | transactionMethodsAPI |
| `TOKEN_EXPIRED` | 401 | Access token expired | backendClient (auto-refresh) |
| `TOKEN_INVALID` | 401 | JWT malformed | backendClient |
| `TOKEN_REUSE_DETECTED` | 401 | Refresh token reuse | backendClient |
| `MUST_CHANGE_PASSWORD` | 403 | Must change password first | proxy.ts middleware |
| `FORBIDDEN` | 403 | Insufficient role | API routes |
| `USER_NOT_FOUND` | 404 | No user found | manageAPI |
| `ACCOUNT_NOT_FOUND` | 404 | No account found | transactionMethodsAPI |
| `EMAIL_EXISTS` | 409 | Duplicate email | registerAPI |
| `NATIONAL_ID_EXISTS` | 409 | Duplicate national ID | registerAPI |
| `INSUFFICIENT_FUNDS` | 400 | Balance too low | transactionMethodsAPI |
| `CURRENCY_MISMATCH` | 400 | Different currencies | transactionMethodsAPI |
| `SAME_ACCOUNT` | 400 | Transfer to self | transactionMethodsAPI |
| `CANNOT_DELETE_ADMIN` | 409 | Last admin | deleteAPI, Delete.tsx |
| `INVALID_CURRENT_PASSWORD` | 401 | Wrong current password | changePasswordAPI |
| `INTERNAL_ERROR` | 500 | Server error | All API routes |
