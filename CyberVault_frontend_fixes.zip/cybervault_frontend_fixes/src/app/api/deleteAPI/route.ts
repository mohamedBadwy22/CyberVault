// src/app/api/deleteAPI/route.ts
// Proxies DELETE /api/v1/users/:id
//
// Backend spec §8.3 DELETE /users/:id:
//   200: { data: { message: 'User deleted successfully' } }
//   404: USER_NOT_FOUND
//   409: CANNOT_DELETE_ADMIN
//
// The backend handles all FK cleanup in the correct order:
//   notifications → audit_events → refresh_tokens → transactions → account → user
// Only admins can delete users (spec §7.6 role matrix).

import { NextResponse } from "next/server";
import { backendFetch, apiErrorResponse, ApiError } from "@/src/lib/backendClient";

export async function POST(request: Request) {
  try {
    const { whoWeDelete, id } = await request.json();

    if (!id) {
      return NextResponse.json(
        { ok: false, error: { code: "VALIDATION_ERROR", message: "User id is required." } },
        { status: 400 }
      );
    }

    // Backend spec §8.3: DELETE /users/:id (admin only)
    const { data } = await backendFetch<{ message: string }>(
      `/users/${encodeURIComponent(String(id))}`,
      { method: "DELETE" }
    );

    return NextResponse.json({ ok: true, message: data.message });
  } catch (err) {
    const errResponse = apiErrorResponse(err);
    const httpStatus = err instanceof ApiError ? err.httpStatus : 500;

    return NextResponse.json(
      { ok: false, error: errResponse.error },
      { status: httpStatus }
    );
  }
}
